shell command for update

sudo wget -c -O /home/pi/server.js "https://amakaroff82.github.io/scanner/scanerPI/server.js"